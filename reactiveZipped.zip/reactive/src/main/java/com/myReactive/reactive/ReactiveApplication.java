package com.myReactive.reactive;

import java.io.IOException;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.myReactive.reactiveSources.ReactiveSources;

@SpringBootApplication
public class ReactiveApplication {

	public static void main(String[] args) throws IOException{
		SpringApplication.run(ReactiveApplication.class, args);
		
		ReactiveSources.intNumberFlux().subscribe(element->System.out.println(element));
		
		ReactiveSources.userFlux().subscribe(user->System.out.println(user));
		
		List<Integer> numbersList=ReactiveSources.intNumberFlux().toStream().toList();
		
		System.out.println("list is"+numbersList);
		System.out.println("size of list"+numbersList.size());
		
		ReactiveSources.intNumberMono().subscribe(element->System.out.println(element));
		System.out.println("press a key to end"); System.in.read();
		 
		 
		 
	}

}
