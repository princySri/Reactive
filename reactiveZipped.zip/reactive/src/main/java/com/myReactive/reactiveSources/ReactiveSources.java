package com.myReactive.reactiveSources;

import java.time.Duration;

import com.myReactive.models.User;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class ReactiveSources {
	
	public static Flux<String> stringNumberFlux(){
		
		return Flux.just("one","two","three","four","five","six","seven","eight","nine","ten").
				delayElements(Duration.ofSeconds(1));
	}
	
	public static Flux<Integer> intNumberFlux(){
		return Flux.range(1, 10).delayElements(Duration.ofSeconds(1));
	}
	
	public static Flux<Integer> intNumberFluxWithException(){
		return Flux.range(1, 10).delayElements(Duration.ofSeconds(1)).map(e->{
			if(e==5)
				throw new RuntimeException("an error happened in flux");
			    return e;
		});
	}
	
	public static Mono<Integer> intNumberMono(){
		return Mono.just(42).delayElement(Duration.ofSeconds(1));
	}
	
	public static Flux<User> userFlux(){
		return Flux.just(new User(123,"apoorva","srivastava"),new User(456,"Princy","Srivastava")).delayElements(Duration.ofSeconds(1));
	}

}
